package com.example.eurekaStudent;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EurekaStudentApplicationTests {

	@Test
	void contextLoads() {
	}

}
