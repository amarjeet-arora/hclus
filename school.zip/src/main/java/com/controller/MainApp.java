package com.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.domain.Studentdelegate;

@RestController
public class MainApp {
	
	@Autowired
	Studentdelegate studentdelegate;
	
	@GetMapping("/loadstudents/{schoolname}")
	public String getStudents(@PathVariable("schoolname")String name) {
		
		return studentdelegate.callStudent(name);
	}

}
