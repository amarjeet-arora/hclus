package com.domain;

public class Student {
private String studenyName;
private String studentClass;
public String getStudenyName() {
	return studenyName;
}
public void setStudenyName(String studenyName) {
	this.studenyName = studenyName;
}
public String getStudentClass() {
	return studentClass;
}
public void setStudentClass(String studentClass) {
	this.studentClass = studentClass;
}
public Student(String studenyName, String studentClass) {
	super();
	this.studenyName = studenyName;
	this.studentClass = studentClass;
}
@Override
public String toString() {
	return "Student [studenyName=" + studenyName + ", studentClass=" + studentClass + "]";
}
public Student() {
	super();
	// TODO Auto-generated constructor stub
}

}
