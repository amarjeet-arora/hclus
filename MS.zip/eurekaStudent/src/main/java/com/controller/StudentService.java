package com.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.domain.Student;

@RestController
public class StudentService {
	
	
	private static Map<String, List<Student>> schooldb= new HashMap<>();
	
	static {
		schooldb= new HashMap<String,List<Student>>();
		List<Student> lst= new ArrayList<Student>();
		
		Student st1= new Student("amar", "class1");
		lst.add(st1);
		st1= new Student("amar", "class1");
		lst.add(st1);
		schooldb.put("abcschool", lst);
		
		
		//schooldb.put("xyz school", lst2);
		
	}
	@RequestMapping(value = "/getstudentdetails/{schoolname}")
	public List<Student> getStudents(@PathVariable("schoolname")String name){
		List<Student> stulist=null;
		try {
			Thread.sleep(1000);
		
			stulist=schooldb.get(name);
		if(stulist ==null) {
			stulist= new ArrayList<Student>();
			Student st1= new Student("Not found","NA");
			stulist.add(st1);
		}}catch (Exception e) {
			
		}
		return stulist;
		
		
		
	}
	
	
	
	
	
	

}
