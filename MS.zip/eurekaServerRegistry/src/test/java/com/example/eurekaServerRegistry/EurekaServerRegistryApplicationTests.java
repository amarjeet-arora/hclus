package com.example.eurekaServerRegistry;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EurekaServerRegistryApplicationTests {

	@Test
	void contextLoads() {
	}

}
